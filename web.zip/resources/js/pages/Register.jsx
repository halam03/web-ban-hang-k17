﻿import AuthPage from './Auth';

const Register = () => <AuthPage initialTab="register" />;

export default Register;
