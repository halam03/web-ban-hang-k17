﻿import AuthPage from './Auth';

const Login = () => <AuthPage initialTab="login" />;

export default Login;
