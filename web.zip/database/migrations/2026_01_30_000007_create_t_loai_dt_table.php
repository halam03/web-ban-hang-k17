<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('t_loai_dt', function (Blueprint $table) {
            $table->string('ma_dt', 25)->primary();
            $table->string('ten_loai', 100)->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('t_loai_dt');
    }
};
